package com.littlebig.administracionlibros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
public class AdministracionlibrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdministracionlibrosApplication.class, args);
	}

}
