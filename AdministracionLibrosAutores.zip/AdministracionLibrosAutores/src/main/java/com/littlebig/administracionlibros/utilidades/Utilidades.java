package com.littlebig.administracionlibros.utilidades;

public class Utilidades {

    public static boolean esCampoNuloVacio(String campo){
        return campo == null || campo.equals("");
    }
}
